module.exports = {
	"fruitCal" : {
	"apple" : 95,
	"orange" : 45,
	"banana" : 105,
	"mango" : 201,
	"watermelon" : 85,
	"peach" : 59}
}